package player;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;


public class Hand {
	private LinkedHashMap<Float, Card> order_by_val = new LinkedHashMap<Float, Card>();
	private ArrayList<String> cardList = new ArrayList<String>();
	
	public Hand(Card[] cards){
		for(Card card : cards){
			float i = (float) (Integer.parseInt(card.suit)*.001);
			order_by_val.put(card.value+i, card);
			cardList.add(card.toString());
		}
	}
	
	public String[] permute2CardHands() {
		String RANDOM_HAND = ":xxx";
		String[] ans = new String[6];
		ans[0] = cardList.get(0) + cardList.get(1) + RANDOM_HAND;
		ans[1] = cardList.get(0) + cardList.get(2) + RANDOM_HAND;
		ans[2] = cardList.get(0) + cardList.get(3) + RANDOM_HAND;
		ans[3] = cardList.get(1) + cardList.get(2) + RANDOM_HAND;
		ans[4] = cardList.get(1) + cardList.get(3) + RANDOM_HAND;
		ans[5] = cardList.get(2) + cardList.get(3) + RANDOM_HAND;
		return ans;
	}
		
	public String toString(){
		StringBuilder ans = new StringBuilder();
		for(Entry<Float, Card> pair: order_by_val.entrySet()){
			ans.append(pair.getValue().toString());
		}
		return ans.toString();
	}
}
