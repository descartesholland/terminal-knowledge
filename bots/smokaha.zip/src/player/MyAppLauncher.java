package player;

import com.jdotsoft.jarloader.JarClassLoader;

public class MyAppLauncher {

    public static void main(String[] args) {
        JarClassLoader jcl = new JarClassLoader();
        try {
            jcl.invokeMain("player.Main", args);
        } catch (Throwable e) {
            e.printStackTrace();
        }
    } 
    
} 