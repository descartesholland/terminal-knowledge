java -jar pokerbot.jar "$@"
