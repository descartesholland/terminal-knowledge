Place your libraries to be included in the One-Jar archive here.
