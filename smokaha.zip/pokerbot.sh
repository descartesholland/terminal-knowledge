java -jar termOne.jar "$@"
